<h1 align="center">
  MBF
</h1>
<h4 align="center">
  Multi brute force Facebook
</h4>
<div align="center">
  <a href="https://github.com/dz-id">
    <img alt="Python Version" src="https://img.shields.io/badge/python-3.8-blue.svg"/>
  </a>
  <a href="https://github.com/dz-id">
    <img alt="Last Commit" src="https://img.shields.io/github/last-commit/dz-id/mbf.svg"/>
  </a>
  <a href="https://github.com/dz-id">
    <img alt="Language" src="https://img.shields.io/github/languages/count/dz-id/mbf.svg"/>
  </a>
  <a href="https://github.com/dz-id">
    <img alt="Top Language" src="https://img.shields.io/github/languages/top/dz-id/mbf.svg"/>
  </a>
  <a href="https://github.com/dz-id">
    <img alt="Search" src="https://img.shields.io/github/search/dz-id/mbf/mbf.svg"/>
  </a>
  <a href="https://github.com/dz-id">
    <img alt="Repo Size" src="https://img.shields.io/github/repo-size/dz-id/mbf.svg"/>
  </a>
  <a href="https://github.com/dz-id">
    <img alt="Starts" src="https://img.shields.io/github/stars/dz-id/mbf.svg"/>
  </a>
  <a href="https://github.com/dz-id">
    <img alt="Forks" src="https://img.shields.io/github/forks/dz-id/mbf.svg"/>
  </a>
</div>
<p align="center">
 <img src="https://github.com/dz-id/mbf/blob/master/screenshot/1.png" width="640" title="ScreenShot" alt="ScreenShot">
</p>

### Fitures
```
- Dump id teman
- Dump id publik
- Dump id reactions post
- Dump id pencarian nama
- Dump id postingan member group
- Multi acc login ( menyimpan sessi login yg sebelumnya jadi tidak usah masukan cookies lg, selagi masih valid si cookiesnya )
- Mutli type login
   - Cokies
   - User pass
   - Token
```
### Install
```
pkg install python git
git clone https://github.com/dz-id/mbf
python -m pip install -r mbf/requirements.txt
```
### And run this script
```
cd mbf
python run.py
```
